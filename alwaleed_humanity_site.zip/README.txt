
=== Alwaleed Philanthropies Mini Website ===

محتويات الملف:
1. index.html      -> الموقع كامل (ثنائي اللغة) في ملف واحد.
2. README.txt      -> هذا الملف.

كيفية النشر السريع:
-------------------
الخيار 1: Vercel (الأبسط)
    - افتح https://vercel.com/import
    - اسحب ملف index.html داخل النافذة (أو ارفع المجلد كاملاً)
    - أنشئ حسابًا سريعًا (بالحساب الشخصي أو جوجل)
    - سيعطيك رابطًا مباشرًا مثل https://yourproject.vercel.app

الخيار 2: Netlify
    - افتح https://app.netlify.com/drop
    - اسحب ملف index.html
    - سيتم إنشاء رابط فوري.

الخيار 3: استضافة تقليدية
    - ارفع index.html إلى مجلد public_html في الاستضافة.
    - اربط اسم النطاق بالمجلد.

عند أي استفسار، تواصل معنا.
